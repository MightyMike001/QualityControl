# QC React App (Vite)

Dit project is klaar om te deployen. Je hoeft lokaal niets te doen.
Kies één van de twee routes:

## Route A — Vercel (aanrader)
1. Zet deze map op GitHub (Upload code → nieuwe repo).
2. Ga naar vercel.com → **Add New Project** → importeer je GitHub-repo.
3. Framework: **Vite**. Build command: `npm run build`, Output: `dist`.
4. Klaar. Vercel bouwt en host automatisch bij elke push.

## Route B — GitHub Pages (automatisch met workflow)
1. Zet deze map op GitHub.
2. Ga naar je repo **Settings → Pages**.
3. Kies **Source: GitHub Actions**. De meegeleverde workflow bouwt en publiceert.
4. Wacht even en je site staat live onder GitHub Pages.

> Let op: gebruik je een submap op GitHub Pages, zet dan in `vite.config.js` de `base`-optie goed.

## Ontwikkelen (optioneel, lokaal)
- `npm install`
- `npm run dev`

## Inhoud
- `src/QCApp.jsx` — jouw app (geïmporteerde JSX)
- `src/main.jsx` — mount de app
- `index.html` — root en Tailwind via CDN
- `vite.config.js` — Vite config
- `.github/workflows/gh-pages.yml` — GitHub Pages deploy workflow