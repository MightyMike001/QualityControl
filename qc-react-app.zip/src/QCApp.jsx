import React, { useEffect, useMemo, useRef, useState } from "react";
import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = "https://kyzpxfkzugxlqfxhadhr.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5enB4Zmt6dWd4bHFmeGhhZGhyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE2Mzk2MDYsImV4cCI6MjA3NzIxNTYwNn0.Qw7JpA_v8vbC4R2qLX1xkzp2qo1LlAc0sz-s5NdsU5Y";
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

function uid(){return Math.random().toString(36).slice(2)+Date.now().toString(36)}

function IOSegmented({ value, onChange, options=[] }){
  return (
    <div className="inline-flex rounded-full bg-slate-100 p-1 border border-slate-200 shadow-inner">
      {options.map(opt => (
        <button key={opt.value} type="button" onClick={()=>onChange(opt.value)} className={`px-3 md:px-4 py-1.5 text-sm rounded-full transition-all ${value===opt.value?"bg-white shadow-sm text-slate-900":"text-slate-600 hover:text-slate-900"}`}>{opt.label}</button>
      ))}
    </div>
  )
}

function PillButton({children,className="",...rest}){return <button {...rest} className={`px-4 py-2 rounded-full border bg-white text-slate-900 shadow-sm active:scale-[0.99] transition ${className}`}>{children}</button>}
function Badge({children,tone="slate"}){const tones={slate:"bg-slate-100 text-slate-700 border-slate-200",green:"bg-emerald-100 text-emerald-700 border-emerald-200",red:"bg-rose-100 text-rose-700 border-rose-200"};return <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs ${tones[tone]||tones.slate}`}>{children}</span>}

function quoteCSV(s){const v=String(s??"");return(v.includes(",")||v.includes("\"")||v.includes("\n"))?'"'+v.replace(/"/g,'""')+'"':v}
function buildCSV(data){const headers=["Datum","Meldingnummer","Serienummer","Initialen","Melding","Opmerking","Goedkeur","Foto's (aantal)"];const rows=data.map(r=>[r.date,r.meldingnummer,r.serienummer,r.initialen,quoteCSV(r.melding),quoteCSV(r.opmerking||""),r.goedkeur,String(r.photos?.length||0)]);return[headers.join(","),...rows.map(row=>row.join(","))].join("\n")}

function isValidSerienummer(v){return/^[A-Z0-9]{10,}$/.test(v)}
function isValidMeldingnummer(v){return/^[A-Z][0-9]{5}$/.test(v)}
function normAlnumUpper(v){return String(v||"").toUpperCase().replace(/[^A-Z0-9]/g,"")}
function mapApprovalToStatus(v){return v==="ja"?"GOEDGEKEURD":"AFGEKEURD"}
function statusBadgeTone(s){return s==="GOEDGEKEURD"?"green":s==="AFGEKEURD"?"red":"slate"}
function parseReport(report){const t=String(report||"");const m=t.match(/^\[M#([A-Z][0-9]{5})\]\s*(.*)$/);return{meldingnummer:m?m[1]:"",opmerking:m?m[2]:t}}
function makeReport(meldingnummer,opmerking){return`[M#${meldingnummer}] ${opmerking||""}`.trim()}

async function uploadToBucket(fileOrBlob,destPath,contentType){const{data,error}=await supabase.storage.from("qc-photos").upload(destPath,fileOrBlob,{upsert:true,contentType});if(error)throw error;return data.path}
function dataUrlToBlob(dataUrl){const[h,b64]=String(dataUrl).split(",");const mime=(h.match(/data:(.*);base64/)||[])[1]||"image/jpeg";const bin=atob(b64||"");const arr=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);return new Blob([arr],{type:mime})}

export default function QCApp(){
  const[records,setRecords]=useState([]);
  const[view,setView]=useState("cards");
  const[q,setQ]=useState("");
  const[filterApproval,setFilterApproval]=useState("all");
  const[date,setDate]=useState("");
  const[melding,setMelding]=useState("");
  const[meldingnummer,setMeldingnummer]=useState("");
  const[serienummer,setSerienummer]=useState("");
  const[initialen,setInitialen]=useState("");
  const[opmerking,setOpmerking]=useState("");
  const[goedkeur,setGoedkeur]=useState("ja");
  const[photos,setPhotos]=useState([]);
  const[errors,setErrors]=useState({});
  const[cameraOpen,setCameraOpen]=useState(false);
  const[searchSerie,setSearchSerie]=useState("");
  const[searchMeldingNr,setSearchMeldingNr]=useState("");
  const[busy,setBusy]=useState(false);
  const[conn,setConn]=useState({state:"init",msg:""});
  const fileInputRef=useRef(null);

  useEffect(()=>{ping();refresh();},[]);

  async function ping(){
    const { data, error } = await supabase.from("qc_record").select("id").limit(1);
    if(error){setConn({state:"err",msg:error.message});}else{setConn({state:"ok",msg: data?.length?"Records geladen":"Verbonden"});}
  }

  async function refresh(){
    const { data, error } = await supabase
      .from("qc_record")
      .select("id, serial, worker_initials, status, report, description, qc_date, created_at, qc_photo(storage_path)")
      .order("created_at",{ascending:false});
    if(error){setConn({state:"err",msg:error.message});return}
    const mapped=(data||[]).map(r=>{
      const { meldingnummer: mn, opmerking: rep } = parseReport(r.report);
      const photos=(r.qc_photo||[]).map(p=>({name:(p.storage_path||"").split("/").pop(),dataUrl:supabase.storage.from("qc-photos").getPublicUrl(p.storage_path).data.publicUrl}));
      return{ id:r.id, date:r.qc_date, melding:r.description||"", meldingnummer:mn, serienummer:r.serial, initialen:r.worker_initials, opmerking:rep, goedkeur:r.status==="GOEDGEKEURD"?"ja":r.status==="AFGEKEURD"?"nee":"ja", status:r.status, photos, createdAt:r.created_at };
    });
    setRecords(mapped);
  }

  function resetForm(){setDate("");setMelding("");setMeldingnummer("");setSerienummer("");setInitialen("");setOpmerking("");setGoedkeur("ja");setPhotos([]);setErrors({});if(fileInputRef.current)fileInputRef.current.value=""}

  function validate(){
    const e={};
    const mNr=normAlnumUpper(meldingnummer);
    const sNr=normAlnumUpper(serienummer);
    if(!date)e.date="Datum is verplicht";
    if(!mNr)e.meldingnummer="Meldingnummer is verplicht";
    if(mNr&&!isValidMeldingnummer(mNr))e.meldingnummer="Meldingnummer: letter + 5 cijfers";
    if(!sNr)e.serienummer="Serienummer is verplicht";
    if(sNr&&!isValidSerienummer(sNr))e.serienummer="Serienummer: min. 10 tekens, A-Z en 0-9";
    if(!initialen)e.initialen="Initialen zijn verplicht";
    if(!goedkeur)e.goedkeur="Kies ja of nee";
    if(!melding)e.melding="Melding is verplicht";
    if((photos?.length||0)<3)e.photos="Maak minimaal 3 foto's";
    setErrors(e);return Object.keys(e).length===0;
  }

  async function handleAddRecord(ev){
    ev.preventDefault(); if(!validate()||busy) return; setBusy(true);
    try{
      const uploadPaths=[];
      for(let i=0;i<photos.length;i++){
        const p=photos[i]; const blob=dataUrlToBlob(p.dataUrl); const ext=(blob.type||"image/jpeg").split("/")[1]||"jpg"; const path=`web/${Date.now()}_${i}_${uid()}.${ext}`; const storedPath=await uploadToBucket(blob,path,blob.type); uploadPaths.push(storedPath);
      }
      const input={p_description:String(melding).trim(),p_photo_paths:uploadPaths,p_qc_date:date||null,p_report:makeReport(normAlnumUpper(meldingnummer),opmerking||""),p_serial:normAlnumUpper(serienummer),p_status:mapApprovalToStatus(goedkeur),p_worker_initials:String(initialen).toUpperCase().trim()};
      const { data, error } = await supabase.rpc("qc_insert_record_with_photos",input);
      if(error) throw error; resetForm(); await refresh(); setConn({state:"ok",msg:"Record opgeslagen"});
    }catch(err){ setConn({state:"err",msg:String(err.message||err)}) }
    finally{ setBusy(false) }
  }

  function handleDeleteLocal(id){setRecords(r=>r.filter(x=>x.id!==id))}
  function handlePhotoChange(files){ if(!files||!files.length)return; const toLoad=Array.from(files).slice(0,Math.max(0,12-photos.length)); const readers=toLoad.map(f=>new Promise(resolve=>{const fr=new FileReader();fr.onload=()=>resolve({name:f.name,dataUrl:fr.result});fr.readAsDataURL(f)})); Promise.all(readers).then(arr=>setPhotos(p=>[...p,...arr])) }
  function removePhoto(idx){setPhotos(p=>p.filter((_,i)=>i!==idx))}

  const filtered=useMemo(()=>{const term=q.trim().toLowerCase();const serieKey=normAlnumUpper(searchSerie);const meldKey=normAlnumUpper(searchMeldingNr);return records.filter(r=>{const appr=r.status?(r.status==="GOEDGEKEURD"?"ja":"nee"):r.goedkeur; if(filterApproval!=="all"&&appr!==(filterApproval==="yes"?"ja":"nee"))return false; if(serieKey&&normAlnumUpper(r.serienummer)!==serieKey)return false; if(meldKey&&normAlnumUpper(r.meldingnummer)!==meldKey)return false; if(!term)return true; const hay=`${r.date} ${r.melding} ${r.meldingnummer} ${r.serienummer} ${r.initialen} ${r.opmerking} ${appr}`.toLowerCase(); return hay.includes(term)})},[records,q,filterApproval,searchSerie,searchMeldingNr])

  function downloadCSV(){const csv=buildCSV(filtered);const blob=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8;"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`qc_export_${new Date().toISOString().slice(0,10)}.csv`;a.click();URL.revokeObjectURL(url)}
  function downloadJSON(){const blob=new Blob([JSON.stringify(filtered,null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`qc_records_${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(url)}

  return (
    <div className="min-h-screen text-slate-900 bg-gradient-to-b from-slate-50 to-white">
      <header className="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-white/70 border-b">
        <div className="mx-auto max-w-6xl px-4">
          <div className="flex items-center justify-between py-2">
            <div className="size-9 rounded-2xl bg-slate-900 text-white grid place-items-center font-bold">QC</div>
            <div className="flex items-center gap-2">
              <IOSegmented value={view} onChange={setView} options={[{value:"cards",label:"Kaarten"},{value:"table",label:"Tabel"}]} />
              <PillButton onClick={downloadCSV} className="hidden md:inline-flex">Exporteer CSV</PillButton>
              <PillButton onClick={downloadJSON} className="hidden md:inline-flex">Exporteer JSON</PillButton>
              <PillButton onClick={()=>{ping();refresh();}} className="hidden md:inline-flex">Verversen</PillButton>
            </div>
          </div>
          <div className="py-2 pb-3">
            <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">Kwaliteitscontrole</h1>
            <p className="text-sm text-slate-500">Supabase · Minimaal 3 foto's · Zoek op serie- en meldingnummer</p>
          </div>
          <div className={`mb-2 text-sm ${conn.state==="ok"?"text-emerald-700":""} ${conn.state==="err"?"text-rose-700":""}`}>
            {conn.state==="init"?"Verbinding controleren…":conn.msg}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-28">
        <section className="mt-4 grid grid-cols-1 md:grid-cols-5 gap-3 items-stretch">
          <div className="md:col-span-2">
            <div className="rounded-2xl border border-slate-200 bg-white/80 shadow-sm focus-within:ring-2 focus-within:ring-slate-200">
              <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Vrije zoekterm…" className="w-full bg-transparent px-4 py-3 text-[15px] outline-none" />
            </div>
          </div>
          <input value={searchSerie} onChange={e=>setSearchSerie(normAlnumUpper(e.target.value))} placeholder="Filter: Serienummer" className="rounded-2xl border border-slate-200 px-3.5 py-2.5 bg-white" />
          <input value={searchMeldingNr} onChange={e=>setSearchMeldingNr(normAlnumUpper(e.target.value))} placeholder="Filter: Meldingnummer" className="rounded-2xl border border-slate-200 px-3.5 py-2.5 bg-white" />
          <IOSegmented value={filterApproval} onChange={setFilterApproval} options={[{value:"all",label:"Alles"},{value:"yes",label:"Ja"},{value:"no",label:"Nee"}]} />
        </section>

        <section className="mt-5">
          <div className="rounded-3xl border border-slate-200 bg-white/90 shadow-md overflow-hidden">
            <div className="px-5 py-4 border-b bg-gradient-to-b from-white to-slate-50">
              <h2 className="text-base md:text-lg font-semibold">Nieuwe kwaliteitscontrole</h2>
            </div>
            <form onSubmit={handleAddRecord} className="p-5 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[13px] text-slate-600 mb-1">Datum *</label>
                <input type="date" value={date} onChange={e=>setDate(e.target.value)} className={`w-full rounded-2xl border px-3.5 py-2.5 bg-slate-50 shadow-inner ${errors.date?"border-rose-500":"border-slate-200"}`} />
                {errors.date&&<p className="text-xs text-rose-600 mt-1">{errors.date}</p>}
              </div>
              <div>
                <label className="block text-[13px] text-slate-600 mb-1">Meldingnummer *</label>
                <input value={meldingnummer} onChange={e=>setMeldingnummer(normAlnumUpper(e.target.value))} placeholder="Bijv. A12345" className={`w-full rounded-2xl border px-3.5 py-2.5 bg-slate-50 shadow-inner ${errors.meldingnummer?"border-rose-500":"border-slate-200"}`} />
                {errors.meldingnummer&&<p className="text-xs text-rose-600 mt-1">{errors.meldingnummer}</p>}
              </div>
              <div>
                <label className="block text-[13px] text-slate-600 mb-1">Serienummer *</label>
                <input value={serienummer} onChange={e=>setSerienummer(normAlnumUpper(e.target.value))} placeholder="Min. 10 tekens, A-Z0-9" className={`w-full rounded-2xl border px-3.5 py-2.5 bg-slate-50 shadow-inner ${errors.serienummer?"border-rose-500":"border-slate-200"}`} />
                {errors.serienummer&&<p className="text-xs text-rose-600 mt-1">{errors.serienummer}</p>}
              </div>
              <div>
                <label className="block text-[13px] text-slate-600 mb-1">Initialen werknemer *</label>
                <input value={initialen} onChange={e=>setInitialen(String(e.target.value).toUpperCase())} placeholder="Bijv. MG" className={`w-full rounded-2xl border px-3.5 py-2.5 bg-slate-50 shadow-inner ${errors.initialen?"border-rose-500":"border-slate-200"}`} />
                {errors.initialen&&<p className="text-xs text-rose-600 mt-1">{errors.initialen}</p>}
              </div>
              <div className="md:col-span-2">
                <label className="block text-[13px] text-slate-600 mb-1">Melding *</label>
                <input value={melding} onChange={e=>setMelding(e.target.value)} placeholder="Korte beschrijving van de melding" className={`w-full rounded-2xl border px-3.5 py-2.5 bg-slate-50 shadow-inner ${errors.melding?"border-rose-500":"border-slate-200"}`} />
                {errors.melding&&<p className="text-xs text-rose-600 mt-1">{errors.melding}</p>}
              </div>
              <div>
                <label className="block text-[13px] text-slate-600 mb-1">Goedkeur *</label>
                <IOSegmented value={goedkeur} onChange={setGoedkeur} options={[{value:"ja",label:"Ja"},{value:"nee",label:"Nee"}]} />
                {errors.goedkeur&&<p className="text-xs text-rose-600 mt-1">{errors.goedkeur}</p>}
              </div>
              <div className="md:col-span-2">
                <label className="block text-[13px] text-slate-600 mb-2">Foto's *</label>
                <div className="flex flex-wrap items-center gap-2">
                  <input ref={fileInputRef} type="file" accept="image/*" capture="environment" multiple onChange={e=>handlePhotoChange(e.target.files)} className="text-sm text-slate-600 file:mr-4 file:rounded-full file:border file:border-slate-200 file:bg-white file:px-4 file:py-2 file:text-slate-900 file:cursor-pointer" />
                  <PillButton type="button" onClick={()=>setCameraOpen(true)} className="bg-slate-900 text-white border-slate-900">Camera</PillButton>
                  <span className={`text-sm ${errors.photos?"text-rose-600":"text-slate-600"}`}>{photos.length}/3</span>
                </div>
                {photos?.length>0&&(
                  <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                    {photos.map((p,i)=>(
                      <figure key={i} className="relative group">
                        <img src={p.dataUrl} alt={p.name} className="h-28 w-full object-cover rounded-2xl border border-slate-200" />
                        <button type="button" onClick={()=>removePhoto(i)} className="absolute top-2 right-2 text-xs px-2 py-1 rounded-full bg-white/90 border border-slate-200 shadow-sm opacity-0 group-hover:opacity-100 transition">Verwijder</button>
                      </figure>
                    ))}
                  </div>
                )}
                {errors.photos&&<p className="text-xs text-rose-600 mt-1">{errors.photos}</p>}
              </div>
              <div className="md:col-span-2 flex items-center gap-2 pt-2">
                <PillButton type="submit" disabled={photos.length<3||busy} className={`border ${photos.length<3||busy?"opacity-60 cursor-not-allowed":"bg-slate-900 text-white border-slate-900"}`}>{busy?"Opslaan…":photos.length<3?"Min. 3 foto's":"Opslaan"}</PillButton>
                <PillButton type="button" onClick={resetForm}>Reset</PillButton>
              </div>
            </form>
          </div>
        </section>

        <section className="mt-6">
          {view==="cards"?<CardsView records={filtered} onDelete={handleDeleteLocal}/>:<TableView records={filtered} onDelete={handleDeleteLocal}/>}
          {filtered.length===0&&<p className="text-center text-slate-500 py-10">Geen meldingen gevonden.</p>}
        </section>

        <section className="mt-8"><TestPanel/></section>
      </main>

      <div className="fixed bottom-0 inset-x-0 z-40 bg-white/90 backdrop-blur border-t">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between gap-3">
          <span className="text-sm text-slate-600 hidden md:inline">{records.length} registraties</span>
          <div className="flex items-center gap-2 ml-auto">
            <IOSegmented value={view} onChange={setView} options={[{value:"cards",label:"Kaarten"},{value:"table",label:"Tabel"}]} />
            <PillButton onClick={downloadCSV}>CSV</PillButton>
            <PillButton onClick={downloadJSON}>JSON</PillButton>
            <PillButton onClick={()=>{ping();refresh();}}>Verversen</PillButton>
          </div>
        </div>
      </div>

      {cameraOpen&&(
        <CameraModal onClose={()=>setCameraOpen(false)} onCapture={shot=>setPhotos(p=>[...p,shot])}/>
      )}
    </div>
  )
}

function CardsView({records,onDelete}){
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {records.map(r=>(
        <article key={r.id} className="rounded-3xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          {r.photos?.length>0&&(
            <div className="grid grid-cols-3 gap-0.5 bg-slate-100">
              {r.photos.slice(0,3).map((p,i)=>(<img key={i} src={p.dataUrl} alt={p.name} className="h-24 w-full object-cover"/>))}
            </div>
          )}
          <div className="p-4">
            <header className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-semibold tracking-tight leading-snug">{r.melding||"(Geen titel)"}</h3>
                <p className="text-xs text-slate-500">{fmtDate(r.date)} · {r.meldingnummer} · {r.serienummer}</p>
              </div>
              <div>{r.status?<Badge tone={statusBadgeTone(r.status)}>{r.status.replace(/_/g,' ')}</Badge>:r.goedkeur==="ja"?<Badge tone="green">Goedgekeurd</Badge>:<Badge tone="red">Afgekeurd</Badge>}</div>
            </header>
            {r.opmerking&&<p className="mt-3 text-[13px] text-slate-700 whitespace-pre-wrap">{r.opmerking}</p>}
            <footer className="mt-4 flex items-center justify-between">
              <div className="text-xs text-slate-500">{r.initialen}</div>
              <PillButton onClick={()=>onDelete(r.id)} className="px-3 py-1.5">Verwijder (lokaal)</PillButton>
            </footer>
          </div>
        </article>
      ))}
    </div>
  )
}

function TableView({records,onDelete}){
  return (
    <div className="overflow-auto rounded-3xl border border-slate-200 bg-white shadow-sm">
      <table className="min-w-full text-sm">
        <thead className="bg-slate-50">
          <tr className="text-left">
            <Th>Datum</Th>
            <Th>Meldingnummer</Th>
            <Th>Serienummer</Th>
            <Th>Initialen</Th>
            <Th>Melding</Th>
            <Th>Opmerking</Th>
            <Th>Status</Th>
            <Th>Foto's</Th>
            <Th></Th>
          </tr>
        </thead>
        <tbody>
          {records.map(r=>(
            <tr key={r.id} className="border-t">
              <Td>{fmtDate(r.date)}</Td>
              <Td>{r.meldingnummer}</Td>
              <Td>{r.serienummer}</Td>
              <Td>{r.initialen}</Td>
              <Td className="max-w-[28ch] truncate" title={r.melding}>{r.melding}</Td>
              <Td className="max-w-[40ch] truncate" title={r.opmerking}>{r.opmerking}</Td>
              <Td>{r.status?r.status.replace(/_/g,' '):(r.goedkeur==="ja"?"GOEDGEKEURD":"AFGEKEURD")}</Td>
              <Td>{r.photos?.length||0}</Td>
              <Td><PillButton onClick={()=>onDelete(r.id)} className="px-3 py-1.5">Verwijder (lokaal)</PillButton></Td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function Th({children}){return<th className="px-3 py-2 text-xs font-semibold text-slate-600">{children}</th>}
function Td({children,className=""}){return<td className={`px-3 py-2 align-top ${className}`}>{children}</td>}

export function fmtDate(v){if(!v)return"";try{const d=new Date(v);if(Number.isNaN(d.getTime()))return v;return d.toLocaleDateString()}catch{return v}}

function CameraModal({onClose,onCapture}){
  const videoRef=useRef(null);const canvasRef=useRef(null);const streamRef=useRef(null);const[ready,setReady]=useState(false);
  useEffect(()=>{let mounted=true;(async()=>{try{const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"}},audio:false});if(!mounted)return;streamRef.current=s;if(videoRef.current){videoRef.current.srcObject=s;videoRef.current.onloadedmetadata=()=>{if(!mounted)return;videoRef.current.play();setReady(true)}}}catch{}})();return()=>{mounted=false;const s=streamRef.current;if(s)s.getTracks().forEach(t=>t.stop());streamRef.current=null}},[])
  function snap(){const v=videoRef.current;const c=canvasRef.current;if(!v||!c)return;const w=v.videoWidth;const h=v.videoHeight;c.width=w;c.height=h;const ctx=c.getContext("2d");ctx.drawImage(v,0,0,w,h);const dataUrl=c.toDataURL("image/jpeg",0.9);onCapture({name:`shot_${Date.now()}.jpg`,dataUrl})}
  return(
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur grid place-items-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden border">
        <div className="p-3 border-b flex items-center justify-between"><div className="font-semibold">Camera</div><button onClick={onClose} className="text-slate-600 px-3 py-1 rounded-full border">Sluit</button></div>
        <div className="p-3">
          <div className="aspect-[3/4] w-full bg-black rounded-xl overflow-hidden grid place-items-center">
            <video ref={videoRef} className="w-full" playsInline muted />
          </div>
          <canvas ref={canvasRef} className="hidden" />
          <div className="mt-3 flex items-center gap-2">
            <PillButton onClick={snap} disabled={!ready} className="bg-slate-900 text-white border-slate-900">Neem foto</PillButton>
            <span className="text-sm text-slate-600">Gebruik de achtercamera indien beschikbaar</span>
          </div>
        </div>
      </div>
    </div>
  )
}

function TestPanel(){
  const[results,setResults]=useState([])
  useEffect(()=>{
    const r=[]
    try{const out=fmtDate("2025-10-30");r.push({name:"fmtDate valid ISO",pass:typeof out==="string"&&out.length>0,out})}catch(e){r.push({name:"fmtDate valid ISO",pass:false,out:String(e)})}
    try{const out=fmtDate("not-a-date");r.push({name:"fmtDate invalid",pass:out==="not-a-date",out})}catch(e){r.push({name:"fmtDate invalid",pass:false,out:String(e)})}
    try{const out=fmtDate("");r.push({name:"fmtDate empty",pass:out==="",out})}catch(e){r.push({name:"fmtDate empty",pass:false,out:String(e)})}
    try{const ok1=isValidSerienummer("ABCDEF1234");const no1=isValidSerienummer("ABC123");r.push({name:"validate serienummer",pass:ok1&&!no1,out:`${ok1}|${no1}`})}catch(e){r.push({name:"validate serienummer",pass:false,out:String(e)})}
    try{const ok2=isValidMeldingnummer("A12345");const no2=isValidMeldingnummer("1A2345");r.push({name:"validate meldingnummer",pass:ok2&&!no2,out:`${ok2}|${no2}`})}catch(e){r.push({name:"validate meldingnummer",pass:false,out:String(e)})}
    try{const csv=buildCSV([{date:"2025-10-30",meldingnummer:"A12345",serienummer:"ABCDEF1234",initialen:"MG",melding:"X",opmerking:"regel 1\nregel 2",goedkeur:"ja",photos:[1,2,3]}]);const pass=csv.includes("A12345")&&csv.includes("ABCDEF1234")&&csv.includes("regel 1");r.push({name:"CSV build",pass,out:csv.slice(0,80)+"…"})}catch(e){r.push({name:"CSV build",pass:false,out:String(e)})}
    setResults(r)
  },[])
  return(
    <div className="rounded-2xl border border-slate-200 bg-white p-4">
      <h3 className="font-semibold mb-2">Automatische tests</h3>
      <ul className="space-y-1">{results.map((t,i)=>(<li key={i} className="text-sm"><span className={`font-medium ${t.pass?"text-emerald-700":"text-rose-700"}`}>{t.pass?"OK":"FAIL"}</span> - {t.name} — <span className="text-slate-600">{String(t.out)}</span></li>))}</ul>
    </div>
  )
}
